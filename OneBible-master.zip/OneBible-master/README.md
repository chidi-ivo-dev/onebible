OneBible application is a web bible app that uses rapidapi bible api to enable user to read bible online. Project built with vanilla php (OOP), jquery, html, mysql, javascript, bootstrap, css.
